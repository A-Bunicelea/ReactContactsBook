import {useState, useReducer} from "react" ;
import logo from './logo.svg';
import './App.css';
import {Route, Switch} from "react-router-dom";
import Login from "./components/Login";
import Contacts from "./components/Contacts";
import About from "./components/About";
import AppContext from "./context/AppContext";
import Logout from "./components/Logout";

function contactReducer(state, action){ 
  console.log("state:", state);
  console.log("action", action);
    switch(action.type)
    {
      case 'ADD':
      const newContact = { info: action.payload}
      const addedContacts = [...state.contacts, newContact]
          return {...state, contacts:addedContacts}
       

      default:
        return state
    }
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [state, dispatch] = useReducer(contactReducer,{contacts:[]});

  return (
   <div>
     <AppContext.Provider value={{"isAuthenticated": isAuthenticated, "setIsAuthenticated": setIsAuthenticated, "state": state, "dispatch": dispatch}}>
     {/* <Navbar /> */}
     <Switch>
       <Route exact path="/contacts">
         <Contacts />
       </Route>

       <Route exact path="/login">
         <Login />
       </Route>

       <Route exact path="/Logout">
         <Logout />
       </Route>
   

       <Route exact path="/about">
         <About />
       </Route>
       </Switch>
       </AppContext.Provider>
     
   </div>
  );
}

export default App;
