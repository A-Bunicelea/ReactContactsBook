import React, {useContext} from "react";
import Navbar from "./Navbar";
function About() {

    return(
        <div>
            <Navbar />
        <div>about page</div>
        </div>
    )
}

export default About;