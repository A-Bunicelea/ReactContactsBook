import React, {useContext, useEffect} from "react";
import AppContext from "../context/AppContext";
import Navbar from "./Navbar";

function Login() {
    const {isAuthenticated, setIsAuthenticated} = useContext(AppContext); 

    useEffect(() => {
        setIsAuthenticated(true);
    }, [isAuthenticated]);

const {msg, setMsg} = useContext(AppContext)
    return(
        <div>
            <Navbar />
        <div>Login page</div>

        </div>
    )
}

export default Login;