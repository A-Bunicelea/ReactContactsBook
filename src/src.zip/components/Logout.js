import React, {useContext, useEffect} from "react";
import AppContext from "../context/AppContext";
import Navbar from "./Navbar";

function Logout() {
    const {isAuthenticated, setIsAuthenticated} = useContext(AppContext); 
    useEffect(() => {
        setIsAuthenticated(false);
    }, [isAuthenticated]);

    return(
        <div>
            <Navbar />
        <div>Logout page</div>

        </div>
    )
}

export default Logout;