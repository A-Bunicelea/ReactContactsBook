import React, {useContext} from "react";
import { NavItem } from "react-bootstrap";
import AppContext from "../context/AppContext";

function Contacts() {
    const {state, dispatch} = useContext(AppContext); 

    return(
        <>
        <div>Contacts page</div>
        <button onClick={() => dispatch({type: "ADD", payload: "test"})}>+</button>
        <pre>{JSON.stringify(state.contacts)}</pre>
        {state.contacts.map((item, index) =>
            <p key={index}>
                {item.info}
            </p>
        )}
        </>
    )
}

export default Contacts;