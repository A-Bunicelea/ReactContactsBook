import React, {useContext} from "react";
import {Link} from "react-router-dom";
import AppContext from "../context/AppContext";
function Navbar() {
    const {isAuthenticated} = useContext(AppContext);
    return(
        <div>
            <ul>
                    <Link to="/contacts">
                        <li>Contacts</li>
                    </Link>

                    <Link to="/about" >
                        <li>About</li>
                    </Link> 
                {(!isAuthenticated)? 
                    <Link to="/login" >
                        <li>Log in</li>
                    </Link> :
                    <Link to="/logout">
                        <li>Log out</li>
                    </Link>}


                </ul>
        </div>
    )
}

export default Navbar;